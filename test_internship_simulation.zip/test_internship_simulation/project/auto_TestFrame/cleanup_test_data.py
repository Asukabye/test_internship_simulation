# -*- coding: utf-8 -*-
"""
删除 Test 用户相关数据脚本
==========================
删除 Test 用户（username='Test'）的：购物车条目、订单、订单明细、库存流水。
- 不删除 Test 用户本身（users 表不动）
- 幂等：无数据时执行无副作用
- 与 build_test_data.py 配合：build 构建数据，本脚本清理数据
"""
import pymysql

DB = dict(host="127.0.0.1", port=3306, database="eshop",
          user="root", passwd="123456", charset="utf8")
TEST_USERNAME = "Test"


def main():
    conn = pymysql.Connect(**DB)
    cur = conn.cursor()
    try:
        cur.execute("SELECT id, username FROM users WHERE username = %s", (TEST_USERNAME,))
        user = cur.fetchone()
        if not user:
            print(f"用户 {TEST_USERNAME} 不存在，无需清理")
            return
        test_id = user[0]
        print(f"开始清理 Test 用户(id={test_id})相关数据...")

        # 按依赖顺序删除：流水 -> 明细 -> 订单 -> 购物车（order_items/ledger 有外键引用 orders）
        cur.execute(
            "DELETE il FROM inventory_ledger il JOIN orders o ON il.order_id = o.id WHERE o.user_id = %s",
            (test_id,))
        n_ledger = cur.rowcount

        cur.execute(
            "DELETE oi FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE o.user_id = %s",
            (test_id,))
        n_items = cur.rowcount

        cur.execute("DELETE FROM orders WHERE user_id = %s", (test_id,))
        n_orders = cur.rowcount

        cur.execute("DELETE FROM cart_items WHERE user_id = %s", (test_id,))
        n_cart = cur.rowcount

        conn.commit()
        print(f"删除完成：库存流水 {n_ledger} 条、订单明细 {n_items} 条、"
              f"订单 {n_orders} 条、购物车条目 {n_cart} 条（已提交）")
        print(f"用户 {TEST_USERNAME} 本身保留（users 表未动）")
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    main()
