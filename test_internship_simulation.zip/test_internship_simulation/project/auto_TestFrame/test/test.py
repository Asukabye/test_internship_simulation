#字典使用jinja2模板
from jinja2 import Template
dict_1 = {'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1IiwidXNlcm5hbWUiOiJUZXN0IiwiaWF0IjoxNzg3ODk5NTA3LCJleHAiOjE3ODc5ODU5MDd9.Il44hObinRch0ogmdxPYid0tKgJT6J0eGq77RsTscUY'}
a = Template("{'Authorization':{{Authorization}}}").render(dict_1)
print(a)





# #预期结果
# import json
# from utils.excel_utils import read_excel
# datas =read_excel(r"D:\study\project\测试实习模拟\E-shop_单接口功能测试用例_已修正.xlsx")
# for data in datas:
#     print(data["ID"],":data['预期结果']=",data["预期结果"])
#     print("json_loads=",json.loads(data["预期结果"]))



# #json.dump()和 json.loads()
# import json
# str1 = '{ "username":"test_1", \n''"password": "123456", \n''"nickname": "test_1" }'
# print(json.loads(str1))
# print(json.dumps(json.loads(str1)))


# #headrs拼接
# from utils.excel_utils import read_excel
# datas =read_excel(r"D:\study\project\测试实习模拟\E-shop_单接口功能测试用例_已修正.xlsx")
# for data in datas:
#     data_headrs = data["请求头"] or "{}"
#     print(data_headrs)


# #url拼接
# #excel表格的路径存请求路径样式，通过jinja2的Template搭建模板，将excel的params值传入模板，构造url
# import json
# import pprint
# from utils.excel_utils import read_excel
# from jinja2 import Template
# datas =read_excel(r"D:\study\project\测试实习模拟\E-shop_单接口功能测试用例_已修正.xlsx")
# for data in datas:
#     params = data["params"] or "{}" #json.loads() 必须接收字符串
#     url = Template(str(data["路径"])).render(json.loads(params))
#     pprint.pprint(url)


# #jinja2拼接
# from jinja2 import Template
# b = {"username":"alice","password":"123456"}
# a = Template('{"username":{{username}}}').render(b)
# print(a)