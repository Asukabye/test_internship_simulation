import openpyxl

def read_excel(path):
    # 打开exel文件
    excel_file = openpyxl.load_workbook(path)

    # 选择表
    worksheet = excel_file['Sheet1']

    # 读取数据，打包为字典
    data = []
    keys = [cell.value for cell in worksheet[2]]
    for row in worksheet.iter_rows(min_row=3,values_only=True):
        dict_data = dict(zip(keys, row))
        #  只添加文件中is_true字段为True的记录（兼容 TRUE/是/1/yes 等写法）
        flag = str(dict_data.get("is_true", "")).strip().lower()
        if flag in ("true", "1", "yes", "y", "是"):
            data.append(dict_data)

    excel_file.close()
    return data
