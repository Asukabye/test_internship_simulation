# -*- coding: utf-8 -*-
"""
Test 用户测试数据构建脚本
=========================
每次执行：先清除 Test 用户的旧数据，再按 E-shop_053 ~ E-shop_151 用例需求插入新数据。
覆盖：
  1. 购物车条目 x3        -> 购物车模块(053-074)：查看购物车 / 加入购物车 / 修改数量
  2. 5种状态订单 x5+明细+库存流水 -> 订单模块(084-130)：订单列表按状态筛选 / 详情 / 取消 / 发货 / 收货
  3. 秒杀商品库存重置       -> 秒杀模块(143-151)：product 11 库存恢复为 5
说明：
  - 固定 id 段 2001+：购物车条目 id=2001~2003，订单 id=2001~2005，与现有预置数据(id<=7)不冲突；
    若希望用例引用 Test 自己的订单，把 Excel 中 order_id 改为 2001~2005 即可。
  - 幂等：重复执行不会累积重复数据。
"""
import sys
import datetime

import pymysql

DB = dict(host="127.0.0.1", port=3306, database="eshop",
          user="root", password="123456", charset="utf8")
TEST_USERNAME = "Test"

# 购物车条目: (cart_item_id, product_id, quantity)
CART_ITEMS = [
    (2001, 3, 2),   # USB-C 快充线 x2
    (2002, 9, 1),   # 不锈钢保温杯 500ml x1
    (2003, 1, 1),   # 无线蓝牙耳机 x1
]

# 订单: (order_id, order_no, status, trade_no, paid_at, shipped_at, completed_at, cancelled_at, items[(product_id, quantity)])
ORDERS = [
    (2001, "TESTSEED202401010001", "PENDING_PAYMENT", None, None, None, None, None,
     [(3, 2), (7, 1)]),  # 待支付 -> 供取消(104)/支付回调(131-140)/创建订单后状态流转
    (2002, "TESTSEED202401020001", "PAID", "TESTSEED20240115001",
     datetime.datetime(2024, 1, 15, 11, 30), None, None, None,
     [(4, 1)]),  # 已支付 -> 供模拟发货(113)
    (2003, "TESTSEED202401030001", "SHIPPED", "TESTSEED20240116001",
     datetime.datetime(2024, 1, 16, 14, 0), datetime.datetime(2024, 1, 16, 14, 0), None, None,
     [(10, 1)]),  # 已发货 -> 供模拟确认收货(122)
    (2004, "TESTSEED202401040001", "COMPLETED", "TESTSEED20240117001",
     datetime.datetime(2024, 1, 17, 9, 30), datetime.datetime(2024, 1, 17, 9, 30),
     datetime.datetime(2024, 1, 17, 9, 30), None,
     [(6, 1)]),  # 已完成
    (2005, "TESTSEED202401050001", "CANCELLED", None, None, None, None,
     datetime.datetime(2024, 1, 18, 16, 0),
     [(8, 1)]),  # 已取消 -> 供幂等取消(110)
]

SECKILL_PRODUCT_ID = 11
SECKILL_STOCK = 5


def main():
    conn = pymysql.Connect(**DB)
    cur = conn.cursor()
    try:
        # 1. 确认 Test 用户（不存在则通过注册接口创建，保证 password_hash 合法）
        cur.execute("SELECT id, username FROM users WHERE username = %s", (TEST_USERNAME,))
        user = cur.fetchone()
        if not user:
            import requests
            r = requests.post("http://127.0.0.1:8000/auth/register",
                              json={"username": TEST_USERNAME, "password": "123456",
                                    "nickname": TEST_USERNAME}, timeout=5)
            if r.status_code not in (200, 201):
                print("Test 用户不存在且注册失败:", r.status_code, r.text)
                sys.exit(1)
            cur.execute("SELECT id, username FROM users WHERE username = %s", (TEST_USERNAME,))
            user = cur.fetchone()
        test_id = user[0]
        # print(f"[1] Test 用户: id={test_id}, username={user[1]}")

        # 2. 清除 Test 用户旧数据（幂等）
        cur.execute("DELETE il FROM inventory_ledger il JOIN orders o ON il.order_id = o.id WHERE o.user_id = %s", (test_id,))
        cur.execute("DELETE oi FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE o.user_id = %s", (test_id,))
        cur.execute("DELETE FROM orders WHERE user_id = %s", (test_id,))
        cur.execute("DELETE FROM cart_items WHERE user_id = %s", (test_id,))
        # print("[2] 已清除 Test 用户旧数据（购物车/订单/明细/流水）")

        # 3. 插入购物车条目
        for cid, pid, qty in CART_ITEMS:
            cur.execute(
                "INSERT INTO cart_items (id, user_id, product_id, quantity, created_at) VALUES (%s, %s, %s, %s, NOW())",
                (cid, test_id, pid, qty))
        # print(f"[3] 已插入购物车条目 x{len(CART_ITEMS)}（id=2001~2003）")

        # 4. 插入订单 + 明细 + 库存流水（先插订单主表，order_items 有外键引用 orders.id）
        for oid, ono, status, trade_no, paid_at, shipped_at, completed_at, cancelled_at, items in ORDERS:
            total = 0.0
            for pid, qty in items:
                cur.execute("SELECT price FROM products WHERE id = %s", (pid,))
                total += float(cur.fetchone()[0]) * qty
            cur.execute(
                """INSERT INTO orders (id, order_no, user_id, total_amount, status, trade_no,
                                       paid_at, shipped_at, completed_at, cancelled_at, created_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())""",
                (oid, ono, test_id, round(total, 2), status, trade_no,
                 paid_at, shipped_at, completed_at, cancelled_at))
            for pid, qty in items:
                cur.execute("SELECT price, name FROM products WHERE id = %s", (pid,))
                price, name = cur.fetchone()
                cur.execute(
                    "INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES (%s, %s, %s, %s, %s)",
                    (oid, pid, name, price, qty))
                cur.execute(
                    "INSERT INTO inventory_ledger (product_id, change_amount, order_id, reason, created_at) VALUES (%s, %s, %s, 'SEED_ORDER', NOW())",
                    (pid, -qty, oid))
            # print(f"    - 订单 {oid} [{status}] 金额 {round(total, 2)}："
            #       + ", ".join(f"商品{pid}x{qty}" for pid, qty in items))
        # print(f"[4] 已插入订单 x{len(ORDERS)}（id=2001~2005，5种状态齐全）+ 明细 + 库存流水")

        # 5. 重置秒杀商品库存（每次执行恢复，保证秒杀用例可下单）
        cur.execute("UPDATE products SET stock = %s WHERE id = %s", (SECKILL_STOCK, SECKILL_PRODUCT_ID))
        # print(f"[5] 已重置秒杀商品库存：product {SECKILL_PRODUCT_ID} stock = {SECKILL_STOCK}")

        conn.commit()
        # print("完成：Test 用户测试数据构建成功（已提交）")
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    main()
