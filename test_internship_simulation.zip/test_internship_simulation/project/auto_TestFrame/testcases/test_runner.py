import json
import pprint
import subprocess
import sys

import allure
import jsonpath
from jinja2 import Template
import pymysql
import pytest
import requests

from utils.excel_utils import read_excel


class TestRunner(object):
    # 读取测试用例文件中的全部数据，用属性保存
    data =read_excel(r"D:\study\project\test_internship_simulation\project\docs\E-shop_单接口功能测试用例.xlsx")
    print("data:")
    print(data)
    # 提取后的数据，初始化一个全局的属性，用空字典保存
    all_data = {}

    @pytest.mark.parametrize("case", data)
    def test_case(self,case):
        #引用全局变量（依赖数据：之前用例提取出来的值，如{{token}}）
        #注意：变量名不要叫all，会遮蔽Python内置函数all()，导致all(...)报错
        all_data = self.all_data
        print(all_data)

        #初始化Allure报告
        allure.dynamic.feature(case["模块_接口"])
        allure.dynamic.title(f"ID:{case['ID']}--Title:{case['标题']}")



        #解析请求数据
        case_params = case["params"] or "{}"
        url = Template(str(case["基准"]+case["路径"])).render(json.loads(case_params))
        case_headers = case["请求头"] or {}
        headers = json.loads(Template(str(case_headers)).render(all_data))
        method = case["请求方式"]
        params = json.loads(case["params"]) if case["params"] else {}
        data = json.loads(case["data"]) if case["data"] else {}
        json_data = json.loads(case["json_data"]) if case["json_data"] else {}
        # files = json.loads(case["files"]) if isinstance(case["files"], str) else None


        #组装请求数据
        request_data = {
            "method": method,
            "url": url,
            "headers": headers,
            "params": params,
            "data": data,
            "json": json_data,
            # "files": files
        }
        print("\n")
        pprint.pprint(request_data)


        #前置处理
        if case["setup"]:
            script = case["setup"]
            subprocess.run([sys.executable, script], check=True)
            print("setup")

        #发起请求
        response = requests.request(**request_data)


        #断言
            #HTTP响应断言
                #把预期结果解析为字典，逐个字段和响应JSON判断
        expected = json.loads(case["预期结果"])
        actual = response.json()
        print("预期结果：",expected)
        print("实际结果",actual)

        for key, value in expected.items():
            actual_value = actual.get(key)
            assert value == actual_value

        #     #SQL断言
        # if case["sql_check"] and case["sql_expected"]:
        #     connect = pymysql.Connect(
        #         host = "127.0.0.1",
        #         port = 3306,
        #         database= "eshop",
        #         user = "root",
        #         passwd = "123456",
        #         charset = "utf8"
        #     )
        #     cursor = connect.cursor()
        #     cursor.execute(case["sql_expected"])
        #     result = cursor.fetchone()
        #     cursor.close()
        #     connect.close()
        #     assert result[0] == case["sql_expected"]


        #提取
            #JSON提取
        if case["JsonExtractDate"]:
            # 提取第一个匹配值
            value = jsonpath.jsonpath(response.json(), case["JsonExtractDate"])[0]
            # 存入全局变量池，键名可自定义，比如用 "token"
            all_data["Authorization"] = value
            print(all_data)

            #数据库提取
        # if case["SqlExtractDate"]:
        #     for key, value in eval(case["SqlExtractDate"]).items():
        #         connect = pymysql.Connect(
        #             host="127.0.0.1",
        #             port=3306,
        #             database="eshop",
        #             user="root",
        #             passwd="123456",
        #             charset="utf8"
        #         )
        #         cursor = connect.cursor()
        #         cursor.execute(value)
        #         result = cursor.fetchone()
        #         cursor.close()
        #         connect.close()
        #         value = result[0]
        #         all[key] = value #SqlExtractDate字段存放的键值对？ 如：{"Username":"SELECT username From users Where username = 'username'"}


        #测试数据销毁
        if case["teardown"]:
            connect = pymysql.Connect(
                        host="127.0.0.1",
                        port=3306,
                        database="eshop",
                        user="root",
                        passwd="123456",
                        charset="utf8",
                        autocommit = True
                    )
            cursor = connect.cursor()
            cursor.execute(case["teardown"])
            result = cursor.fetchone()
            cursor.close()
            connect.close()




