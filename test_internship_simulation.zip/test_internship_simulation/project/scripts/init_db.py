"""数据库初始化与造数脚本

用法(在项目根目录执行):
    python scripts/init_db.py             # 自动建库 + 建表; 已有数据则跳过造数
    python scripts/init_db.py --reset     # 删除全部表后重建并造数(数据会清空)
    python scripts/init_db.py --force     # 不删表, 强制重新造数

说明: 数据库账号密码通过环境变量 DB_HOST/DB_PORT/DB_USER/DB_PASSWORD/DB_NAME 配置,
默认 root / 123456 @ 127.0.0.1:3306, 与 app/config.py 保持一致。
"""
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import create_engine, text  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402

from app import config  # noqa: E402
from app.database import Base, engine  # noqa: E402
from app.models import (  # noqa: E402
    CartItem,
    InventoryLedger,
    Order,
    OrderItem,
    OrderStatus,
    Product,
    Review,
    User,
)
from app.security import hash_password  # noqa: E402


def create_database_if_not_exists():
    """连接 MySQL 服务器(不指定库), 确保业务库存在。"""
    server_engine = create_engine(config.SERVER_URL, isolation_level="AUTOCOMMIT")
    with server_engine.connect() as conn:
        conn.execute(
            text(
                f"CREATE DATABASE IF NOT EXISTS `{config.DB_NAME}` "
                "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
        )
    server_engine.dispose()
    print(f"[init_db] 数据库 {config.DB_NAME} 已就绪")


def seed(session: Session):
    print("[init_db] 开始写入初始数据 ...")

    # ---------- 测试账号(密码均为 123456) ----------
    users = [
        User(username="alice", password_hash=hash_password("123456"), nickname="爱丽丝"),
        User(username="bob", password_hash=hash_password("123456"), nickname="鲍勃"),
        User(username="carol", password_hash=hash_password("123456"), nickname="卡罗尔"),
    ]
    session.add_all(users)
    session.flush()
    alice = users[0]

    # ---------- 商品(含 1 个秒杀商品、1 个无库存商品) ----------
    products = [
        Product(name="无线蓝牙耳机", category="数码", price="199.00", stock=50, description="主动降噪, 续航 30 小时"),
        Product(name="机械键盘 87 键", category="数码", price="299.00", stock=30, description="茶轴, RGB 背光"),
        Product(name="USB-C 快充线 1m", category="数码", price="9.90", stock=200, description="支持 PD 100W 快充"),
        Product(name="纯棉圆领 T 恤", category="服饰", price="59.00", stock=100, description="纯棉 220g, 多色可选"),
        Product(name="直筒牛仔裤", category="服饰", price="129.00", stock=40, description="弹力面料, 修身直筒"),
        Product(name="轻便运动鞋", category="服饰", price="199.00", stock=20, description="透气网面, 缓震鞋底"),
        Product(name="每日坚果礼盒 30 包", category="食品", price="29.90", stock=80, description="每日一包, 科学配比"),
        Product(name="冻干黑咖啡 2g*20 条", category="食品", price="39.90", stock=60, description="冷萃冻干, 即冲即饮"),
        Product(name="不锈钢保温杯 500ml", category="家居", price="49.00", stock=0, description="316 不锈钢, 保温 12 小时(当前缺货)"),
        Product(name="香薰蜡烛礼盒", category="家居", price="19.90", stock=30, description="大豆蜡, 三种香型"),
        Product(
            name="秒杀-便携蓝牙音箱",
            category="数码",
            price="19.90",
            stock=5,
            is_seckill=True,
            description="秒杀商品, 限量 5 件, 先到先得",
        ),
    ]
    session.add_all(products)
    session.flush()
    p = {pr.name: pr for pr in products}

    # ---------- 为 alice 造几张历史订单(覆盖各状态, 便于联调状态机) ----------
    seed_orders = [
        # (状态, {商品名: 数量}, 交易号, 下单时间)
        (OrderStatus.PENDING_PAYMENT, {"USB-C 快充线 1m": 2, "每日坚果礼盒 30 包": 1}, None, datetime(2024, 1, 10, 10, 0, 0)),
        (OrderStatus.PAID, {"纯棉圆领 T 恤": 1}, "SEED20240115001", datetime(2024, 1, 15, 11, 30, 0)),
        (OrderStatus.SHIPPED, {"香薰蜡烛礼盒": 1}, "SEED20240116001", datetime(2024, 1, 16, 14, 0, 0)),
        (OrderStatus.COMPLETED, {"轻便运动鞋": 1}, "SEED20240117001", datetime(2024, 1, 17, 9, 30, 0)),
        (OrderStatus.CANCELLED, {"冻干黑咖啡 2g*20 条": 1}, None, datetime(2024, 1, 18, 16, 0, 0)),
    ]
    for idx, (status, item_map, trade_no, created_at) in enumerate(seed_orders, start=1):
        total = sum(float(p[name].price) * qty for name, qty in item_map.items())
        order = Order(
            order_no=f"SEED202401{idx:02d}0001",
            user_id=alice.id,
            total_amount=total,
            status=status,
            trade_no=trade_no,
            created_at=created_at,
            paid_at=created_at if status in (OrderStatus.PAID, OrderStatus.SHIPPED, OrderStatus.COMPLETED) else None,
            shipped_at=created_at if status in (OrderStatus.SHIPPED, OrderStatus.COMPLETED) else None,
            completed_at=created_at if status == OrderStatus.COMPLETED else None,
            cancelled_at=created_at if status == OrderStatus.CANCELLED else None,
        )
        session.add(order)
        session.flush()
        for name, qty in item_map.items():
            prod = p[name]
            session.add(
                OrderItem(
                    order_id=order.id,
                    product_id=prod.id,
                    product_name=name,
                    price=prod.price,
                    quantity=qty,
                )
            )
            # 种子订单同样占用库存, 保持与真实下单一致
            prod.stock = prod.stock - qty
            session.add(
                InventoryLedger(
                    product_id=prod.id,
                    change_amount=-qty,
                    order_id=order.id,
                    reason="SEED_ORDER",
                )
            )

    # ---------- alice 购物车种子数据(bob/carol 保持空, 便于 CART_EMPTY 场景) ----------
    session.query(CartItem).delete()
    alice_cart = [
        (1, 1),  # 无线蓝牙耳机 199.00 x1
        (3, 2),  # USB-C 快充线 9.90 x2
        (7, 1),  # 每日坚果礼盒 29.90 x1
    ]
    for product_id, qty in alice_cart:
        session.add(CartItem(user_id=alice.id, product_id=product_id, quantity=qty))

    # ---------- 评价种子: alice 对已完成订单(订单4, 轻便运动鞋)的评价 ----------
    session.query(Review).delete()
    completed_order = next((o for o in seed_orders if o[0] == OrderStatus.COMPLETED), None)
    if completed_order is not None:
        completed = (
            session.query(Order)
            .filter(Order.user_id == alice.id, Order.status == OrderStatus.COMPLETED)
            .order_by(Order.id)
            .first()
        )
        if completed is not None and completed.items:
            first_item = completed.items[0]
            session.add(
                Review(
                    order_id=completed.id,
                    order_item_id=first_item.id,
                    user_id=alice.id,
                    product_id=first_item.product_id,
                    rating=5,
                    content="运动鞋很轻便, 尺码标准, 五星好评!",
                )
            )

    session.commit()
    print(
        f"[init_db] 造数完成: 用户 {len(users)} 个(alice/bob/carol, 密码 123456); "
        f"商品 {len(products)} 个(含秒杀商品 1 个); alice 历史订单 {len(seed_orders)} 单; "
        f"alice 购物车 {len(alice_cart)} 条(bob/carol 购物车为空); 评价 1 条(alice 已完成订单)"
    )


def main():
    args = sys.argv[1:]
    reset = "--reset" in args
    force = "--force" in args

    create_database_if_not_exists()

    if reset:
        Base.metadata.drop_all(bind=engine)
        print("[init_db] 已删除全部旧表")

    Base.metadata.create_all(bind=engine)
    print("[init_db] 数据表已就绪")

    with Session(engine) as session:
        has_data = session.query(User).count() > 0
        if has_data and not force:
            print("[init_db] 检测到已有数据, 跳过造数(如需重置请使用 --reset)")
            return
        seed(session)


if __name__ == "__main__":
    main()
