"""导出 OpenAPI 文档到 docs/openapi.json(与在线 /docs 内容一致)。"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.main import app  # noqa: E402

out_path = Path(__file__).resolve().parent.parent / "docs" / "openapi.json"
out_path.parent.mkdir(exist_ok=True)
out_path.write_text(json.dumps(app.openapi(), ensure_ascii=False, indent=2), encoding="utf-8")
print(f"[export_openapi] 已导出到 {out_path}")
