"""请求/响应模型(Pydantic)。"""
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


# ---------- 通用 ----------
class PageOut(BaseModel):
    total: int
    page: int
    page_size: int


# ---------- 用户认证 ----------
class RegisterReq(BaseModel):
    username: str = Field(min_length=3, max_length=20, description="用户名, 3-20 位")
    password: str = Field(min_length=6, max_length=64, description="密码, 6-64 位")
    nickname: str = Field(default="", max_length=30, description="昵称, 可选")


class LoginReq(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    nickname: str
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- 商品 ----------
class ProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    category: str
    price: float
    stock: int
    is_seckill: bool
    description: str


class ProductListOut(PageOut):
    items: list[ProductOut]


# ---------- 购物车 ----------
class CartItemAddReq(BaseModel):
    product_id: int
    quantity: int = Field(ge=1, description="加购数量, 至少 1")


class CartItemUpdateReq(BaseModel):
    quantity: int = Field(description="修改后的数量; 传 0 表示移除该商品")


class CartItemOut(BaseModel):
    id: int
    product_id: int
    product_name: str
    price: float
    quantity: int
    subtotal: float


class CartOut(BaseModel):
    items: list[CartItemOut]
    total_price: float


# ---------- 订单 ----------
class OrderCreateReq(BaseModel):
    cart_item_ids: list[int] | None = Field(
        default=None, description="要结算的购物车条目 ID 列表; 不传(或传 null)表示结算全部购物车"
    )


class OrderItemOut(BaseModel):
    id: int = Field(description="订单明细 ID(评价接口入参 order_item_id 使用)")
    product_id: int
    product_name: str
    price: float
    quantity: int


class OrderOut(BaseModel):
    id: int
    order_no: str
    user_id: int
    total_amount: float
    status: str
    trade_no: str | None = None
    created_at: datetime
    paid_at: datetime | None = None
    shipped_at: datetime | None = None
    completed_at: datetime | None = None
    cancelled_at: datetime | None = None
    items: list[OrderItemOut] = Field(default_factory=list)


class OrderCreateOut(BaseModel):
    id: int
    order_no: str
    total_amount: float
    status: str
    created_at: datetime
    items: list[OrderItemOut] = Field(default_factory=list)


class OrderListOut(PageOut):
    items: list[OrderOut]


# ---------- 支付回调 ----------
class PayCallbackReq(BaseModel):
    order_id: int
    amount: float = Field(description="回调的支付金额(元)")
    trade_no: str = Field(min_length=4, max_length=64, description="支付平台交易号")


# ---------- 秒杀 ----------
class SeckillReq(BaseModel):
    product_id: int
    quantity: int = Field(ge=1, description="抢购数量")


# ---------- 收货地址(v1.1) ----------
class AddressCreateReq(BaseModel):
    receiver: str = Field(min_length=1, max_length=50, description="收货人")
    phone: str = Field(min_length=5, max_length=20, description="手机号")
    province: str = Field(min_length=1, max_length=50, description="省")
    city: str = Field(min_length=1, max_length=50, description="市")
    district: str = Field(min_length=1, max_length=50, description="区/县")
    detail: str = Field(min_length=1, max_length=200, description="详细地址")
    is_default: bool = Field(default=False, description="是否设为默认地址")


class AddressUpdateReq(BaseModel):
    receiver: str = Field(min_length=1, max_length=50)
    phone: str = Field(min_length=5, max_length=20)
    province: str = Field(min_length=1, max_length=50)
    city: str = Field(min_length=1, max_length=50)
    district: str = Field(min_length=1, max_length=50)
    detail: str = Field(min_length=1, max_length=200)
    is_default: bool = Field(default=False, description="是否设为默认地址")


class AddressOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    receiver: str
    phone: str
    province: str
    city: str
    district: str
    detail: str
    is_default: bool
    created_at: datetime


# ---------- 订单评价(v1.1) ----------
class ReviewCreateReq(BaseModel):
    order_item_id: int = Field(description="订单明细 ID(属于当前用户且订单已完成)")
    rating: int = Field(ge=1, le=5, description="评分 1-5")
    content: str = Field(default="", max_length=500, description="评价内容, 可选")


class ReviewOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    order_id: int
    order_item_id: int
    user_id: int
    product_id: int
    product_name: str = ""
    rating: int
    content: str
    created_at: datetime


class ReviewListOut(PageOut):
    items: list[ReviewOut]
