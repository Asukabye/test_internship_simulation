"""用户认证: 注册 / 登录。"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..models import User
from ..schemas import LoginReq, RegisterReq, TokenOut, UserOut
from ..security import create_access_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["用户认证"])


@router.post("/register", response_model=UserOut, status_code=201, summary="用户注册")
def register(req: RegisterReq, db: Session = Depends(get_db)):
    exists = db.query(User).filter(User.username == req.username).first()
    if exists:
        raise errors.biz_error(400, "USER_EXISTS", f"用户名 {req.username} 已被占用")
    user = User(
        username=req.username,
        password_hash=hash_password(req.password),
        nickname=req.nickname or req.username,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenOut, summary="用户登录")
def login(req: LoginReq, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == req.username).first()
    if user is None or not verify_password(req.password, user.password_hash):
        raise errors.biz_error(401, "INVALID_CREDENTIALS", "用户名或密码错误")
    return TokenOut(access_token=create_access_token(user.id, user.username))
