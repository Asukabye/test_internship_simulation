"""购物车: 查看 / 加购 / 修改数量(0=移除)。"""
from decimal import Decimal

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..deps import get_current_user
from ..models import CartItem, Product, User
from ..schemas import CartItemAddReq, CartItemOut, CartOut, CartItemUpdateReq

router = APIRouter(prefix="/cart", tags=["购物车"])


def _cart_item_out(item: CartItem, product: Product) -> dict:
    subtotal = float(product.price * item.quantity)
    return {
        "id": item.id,
        "product_id": product.id,
        "product_name": product.name,
        "price": float(product.price),
        "quantity": item.quantity,
        "subtotal": subtotal,
    }


@router.get("", response_model=CartOut, summary="查看购物车")
def get_cart(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = (
        db.query(CartItem, Product)
        .join(Product, CartItem.product_id == Product.id)
        .filter(CartItem.user_id == user.id)
        .order_by(CartItem.id)
        .all()
    )
    items = []
    total_price = Decimal("0.00")
    for item, product in rows:
        out = _cart_item_out(item, product)
        items.append(out)
        total_price += product.price * item.quantity
    return {"items": items, "total_price": float(total_price)}


@router.post("/items", response_model=CartItemOut, status_code=201, summary="加入购物车")
def add_cart_item(
    req: CartItemAddReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    product = db.get(Product, req.product_id)
    if product is None:
        raise errors.not_found("商品不存在")
    item = (
        db.query(CartItem)
        .filter(CartItem.user_id == user.id, CartItem.product_id == req.product_id)
        .first()
    )
    if item is None:
        item = CartItem(user_id=user.id, product_id=req.product_id, quantity=req.quantity)
        db.add(item)
    else:
        item.quantity += req.quantity
    db.commit()
    db.refresh(item)
    return _cart_item_out(item, product)


@router.put("/items/{item_id}", response_model=CartItemOut, summary="修改购物车数量(0=移除)")
def update_cart_item(
    item_id: int,
    req: CartItemUpdateReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    item = (
        db.query(CartItem)
        .filter(CartItem.id == item_id, CartItem.user_id == user.id)
        .first()
    )
    if item is None:
        raise errors.not_found("购物车条目不存在")
    if req.quantity < 0:
        raise errors.param_error("数量不能为负数")
    if req.quantity == 0:
        db.delete(item)
        db.commit()
        return {
            "id": item_id,
            "product_id": item.product_id,
            "product_name": "",
            "price": 0.0,
            "quantity": 0,
            "subtotal": 0.0,
        }
    item.quantity = req.quantity
    db.commit()
    db.refresh(item)
    product = db.get(Product, item.product_id)
    return _cart_item_out(item, product)
