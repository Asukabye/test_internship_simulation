"""订单评价(v1.1): 对已完成订单的商品明细进行评价。"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..deps import get_current_user
from ..models import Order, OrderItem, OrderStatus, Product, Review, User
from ..schemas import ReviewCreateReq, ReviewListOut, ReviewOut

router = APIRouter(tags=["订单评价(v1.1)"])


def _review_out(review: Review, product_name: str = "") -> dict:
    return {
        "id": review.id,
        "order_id": review.order_id,
        "order_item_id": review.order_item_id,
        "user_id": review.user_id,
        "product_id": review.product_id,
        "product_name": product_name,
        "rating": review.rating,
        "content": review.content,
        "created_at": review.created_at,
    }


@router.post("/reviews", response_model=ReviewOut, status_code=201, summary="提交评价")
def create_review(
    req: ReviewCreateReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """对订单明细提交评价: 仅本人已完成订单可评价, 同一明细只能评价一次。"""
    order_item = db.get(OrderItem, req.order_item_id)
    if order_item is None:
        raise errors.not_found("订单明细不存在")
    order = db.get(Order, order_item.order_id)
    if order is None:
        raise errors.not_found("订单不存在")
    if order.user_id != user.id:
        raise errors.forbidden("无权评价该订单")
    if order.status != OrderStatus.COMPLETED:
        raise errors.biz_error(400, "INVALID_STATE", "仅已完成订单可评价")
    existed = (
        db.query(Review).filter(Review.order_item_id == req.order_item_id).first()
    )
    if existed is not None:
        raise errors.biz_error(400, "ALREADY_REVIEWED", "该商品已评价, 请勿重复提交")
    review = Review(
        order_id=order.id,
        order_item_id=order_item.id,
        user_id=user.id,
        product_id=order_item.product_id,
        rating=req.rating,
        content=req.content,
    )
    db.add(review)
    db.commit()
    db.refresh(review)
    return _review_out(review, product_name=order_item.product_name)


@router.get("/products/{product_id}/reviews", response_model=ReviewListOut, summary="商品评价列表")
def list_product_reviews(
    product_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """公开查询某商品的评价列表(按时间倒序)。"""
    product = db.get(Product, product_id)
    if product is None:
        raise errors.not_found("商品不存在")
    query = db.query(Review).filter(Review.product_id == product_id)
    total = query.count()
    reviews = (
        query.order_by(Review.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    items = []
    for review in reviews:
        order_item = db.get(OrderItem, review.order_item_id)
        items.append(_review_out(review, product_name=order_item.product_name if order_item else ""))
    return {"total": total, "page": page, "page_size": page_size, "items": items}


@router.get("/orders/{order_id}/reviews", response_model=ReviewListOut, summary="我的订单评价列表")
def list_order_reviews(
    order_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """查询某订单下当前用户的评价(仅本人订单, 否则 403)。"""
    order = db.get(Order, order_id)
    if order is None:
        raise errors.not_found("订单不存在")
    if order.user_id != user.id:
        raise errors.forbidden("无权查看该订单的评价")
    reviews = db.query(Review).filter(Review.order_id == order_id).all()
    items = []
    for review in reviews:
        order_item = db.get(OrderItem, review.order_item_id)
        items.append(_review_out(review, product_name=order_item.product_name if order_item else ""))
    return {"total": len(items), "page": 1, "page_size": len(items), "items": items}
