"""商品: 列表(分页/搜索/分类) / 详情。"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..models import Product
from ..schemas import ProductListOut, ProductOut

router = APIRouter(prefix="/products", tags=["商品"])


@router.get("", response_model=ProductListOut, summary="商品列表(分页/搜索/分类)")
def list_products(
    page: int = Query(1, ge=1, description="页码, 从 1 开始"),
    page_size: int = Query(10, ge=1, le=100, description="每页数量, 1-100"),
    keyword: str = "",
    category: str = "",
    db: Session = Depends(get_db),
):
    """分页查询商品列表, 支持按名称模糊搜索与分类过滤。"""
    query = db.query(Product)
    if keyword:
        query = query.filter(Product.name.like(f"%{keyword}%"))
    if category:
        query = query.filter(Product.category == category)
    total = query.count()
    offset = (page - 1) * page_size
    items = query.order_by(Product.id).offset(offset).limit(page_size).all()
    return {"total": total, "page": page, "page_size": page_size, "items": items}


@router.get("/{product_id}", response_model=ProductOut, summary="商品详情")
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.get(Product, product_id)
    if product is None:
        raise errors.not_found("商品不存在")
    return product
