"""收货地址(v1.1): 增删改查 + 设置默认。"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..deps import get_current_user
from ..models import Address, User
from ..schemas import AddressCreateReq, AddressOut, AddressUpdateReq

router = APIRouter(prefix="/addresses", tags=["收货地址(v1.1)"])


def _get_owned_address(db: Session, address_id: int, user_id: int) -> Address:
    address = db.get(Address, address_id)
    if address is None:
        raise errors.not_found("地址不存在")
    if address.user_id != user_id:
        raise errors.forbidden("无权访问该地址")
    return address


def _clear_default(db: Session, user_id: int, except_id: int | None = None):
    """取消用户其他默认地址, 保证每人至多一个默认。"""
    query = db.query(Address).filter(Address.user_id == user_id, Address.is_default.is_(True))
    if except_id is not None:
        query = query.filter(Address.id != except_id)
    for addr in query.all():
        addr.is_default = False


@router.get("", response_model=list[AddressOut], summary="我的地址列表")
def list_addresses(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """查询当前用户全部收货地址, 默认地址排在最前。"""
    addresses = (
        db.query(Address)
        .filter(Address.user_id == user.id)
        .order_by(Address.is_default.desc(), Address.id)
        .all()
    )
    return addresses


@router.post("", response_model=AddressOut, status_code=201, summary="新增地址")
def create_address(
    req: AddressCreateReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """新增收货地址; 首个地址自动设为默认; is_default=true 时取消其他默认。"""
    count = db.query(Address).filter(Address.user_id == user.id).count()
    is_default = req.is_default or count == 0
    if is_default:
        _clear_default(db, user.id)
    address = Address(
        user_id=user.id,
        receiver=req.receiver,
        phone=req.phone,
        province=req.province,
        city=req.city,
        district=req.district,
        detail=req.detail,
        is_default=is_default,
    )
    db.add(address)
    db.commit()
    db.refresh(address)
    return address


@router.put("/{address_id}", response_model=AddressOut, summary="修改地址")
def update_address(
    address_id: int,
    req: AddressUpdateReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """修改地址; 仅本人地址可修改, 否则 403。"""
    address = _get_owned_address(db, address_id, user.id)
    if req.is_default:
        _clear_default(db, user.id, except_id=address.id)
    address.receiver = req.receiver
    address.phone = req.phone
    address.province = req.province
    address.city = req.city
    address.district = req.district
    address.detail = req.detail
    address.is_default = req.is_default
    db.commit()
    db.refresh(address)
    return address


@router.delete("/{address_id}", status_code=204, summary="删除地址")
def delete_address(
    address_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """删除地址; 仅本人地址可删除, 否则 403。删除默认地址后, 若还有地址则将最早的一个设为默认。"""
    address = _get_owned_address(db, address_id, user.id)
    was_default = address.is_default
    db.delete(address)
    if was_default:
        remaining = (
            db.query(Address)
            .filter(Address.user_id == user.id)
            .order_by(Address.id)
            .first()
        )
        if remaining is not None:
            remaining.is_default = True
    db.commit()


@router.put("/{address_id}/default", response_model=AddressOut, summary="设为默认地址")
def set_default_address(
    address_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """将指定地址设为默认(取消其他默认); 仅本人地址可操作, 否则 403。"""
    address = _get_owned_address(db, address_id, user.id)
    _clear_default(db, user.id)
    address.is_default = True
    db.commit()
    db.refresh(address)
    return address
