"""模拟支付: 支付平台回调接口。"""
from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..models import Order, OrderStatus
from ..schemas import PayCallbackReq

router = APIRouter(prefix="/payments", tags=["支付"])


@router.post("/callback", summary="模拟支付回调")
def pay_callback(req: PayCallbackReq, db: Session = Depends(get_db)):
    """模拟支付平台异步回调: 通知某订单支付成功。

    说明: 真实支付平台可能因网络原因对同一笔支付重复推送回调,
    因此回调处理需支持重复调用(幂等)。
    """
    order = db.get(Order, req.order_id)
    if order is None:
        raise errors.not_found("订单不存在")
    order.status = OrderStatus.PAID
    order.paid_at = datetime.now()
    order.trade_no = req.trade_no
    db.commit()
    db.refresh(order)
    return {
        "code": "SUCCESS",
        "message": "支付成功",
        "order_id": order.id,
        "order_no": order.order_no,
        "status": order.status,
    }
