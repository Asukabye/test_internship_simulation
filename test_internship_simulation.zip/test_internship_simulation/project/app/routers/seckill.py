"""简版秒杀: 抢购下单接口(并发热点)。"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..deps import get_current_user
from ..models import Product, User
from ..routers.orders import create_order_from_products, order_out
from ..schemas import OrderCreateOut, SeckillReq

router = APIRouter(prefix="/seckill", tags=["秒杀"])


@router.post("/orders", response_model=OrderCreateOut, status_code=201, summary="秒杀抢购下单")
def seckill_order(
    req: SeckillReq,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """秒杀商品直接下单(不走购物车), 下单即锁定库存。"""
    product = db.get(Product, req.product_id)
    if product is None:
        raise errors.not_found("商品不存在")
    if not product.is_seckill:
        raise errors.biz_error(400, "NOT_SECKILL", "该商品不参与秒杀活动")
    try:
        order, total = create_order_from_products(
            db, user, [(req.product_id, req.quantity)], "SECKILL"
        )
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    db.refresh(order)
    return order_out(order, total_override=total)
