"""订单: 下单 / 列表 / 详情 / 取消 / 模拟发货 / 模拟确认收货。"""
import random
from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from .. import errors
from ..database import get_db
from ..deps import get_current_user
from ..models import CartItem, InventoryLedger, Order, OrderItem, OrderStatus, Product, User
from ..schemas import OrderCreateOut, OrderCreateReq, OrderListOut, OrderOut

router = APIRouter(prefix="/orders", tags=["订单"])


def gen_order_no() -> str:
    return datetime.now().strftime("%Y%m%d%H%M%S") + str(random.randint(100000, 999999))


def order_out(order: Order, total_override: float | None = None) -> dict:
    return {
        "id": order.id,
        "order_no": order.order_no,
        "user_id": order.user_id,
        "total_amount": float(total_override) if total_override is not None else float(order.total_amount),
        "status": order.status,
        "trade_no": order.trade_no,
        "created_at": order.created_at,
        "paid_at": order.paid_at,
        "shipped_at": order.shipped_at,
        "completed_at": order.completed_at,
        "cancelled_at": order.cancelled_at,
        "items": [
            {
                "id": i.id,
                "product_id": i.product_id,
                "product_name": i.product_name,
                "price": float(i.price),
                "quantity": i.quantity,
            }
            for i in order.items
        ],
    }


def create_order_from_products(
    db: Session,
    user: User,
    product_quantities: list[tuple[int, int]],
    source: str,
) -> tuple[Order, Decimal]:
    """下单核心逻辑: 校验库存 -> 扣减库存 -> 生成订单 -> 写库存流水。

    金额使用 Decimal 精确计算(避免浮点尾差); 库存校验与扣减是两步操作(先查后改)。
    """
    if not product_quantities:
        raise errors.biz_error(400, "CART_EMPTY", "没有可结算的商品")

    # 第一步: 逐项校验商品与库存
    order_items = []
    total = Decimal("0.00")
    for product_id, quantity in product_quantities:
        product = db.query(Product).filter(Product.id == product_id).first()
        if product is None:
            raise errors.not_found(f"商品 {product_id} 不存在")
        if product.stock < quantity:
            raise errors.biz_error(400, "INSUFFICIENT_STOCK", f"商品「{product.name}」库存不足")
        order_items.append((product, quantity))
        total += product.price * quantity

    # 第二步: 生成订单并扣减库存
    order = Order(
        order_no=gen_order_no(),
        user_id=user.id,
        total_amount=total,
        status=OrderStatus.PENDING_PAYMENT,
    )
    db.add(order)
    db.flush()
    for product, quantity in order_items:
        db.add(
            OrderItem(
                order_id=order.id,
                product_id=product.id,
                product_name=product.name,
                price=product.price,
                quantity=quantity,
            )
        )
        product.stock = Product.stock - quantity
        db.add(
            InventoryLedger(
                product_id=product.id,
                change_amount=-quantity,
                order_id=order.id,
                reason=source,
            )
        )
    db.flush()
    return order, total


@router.post("", response_model=OrderCreateOut, status_code=201, summary="下单(结算购物车)")
def create_order(
    req: OrderCreateReq | None = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """从购物车下单: 校验库存并扣减, 生成待支付订单, 清空已结算的购物车条目。
    请求体可省略(不传或传空对象均表示结算全部购物车)。"""
    cart_query = db.query(CartItem).filter(CartItem.user_id == user.id)
    if req is not None and req.cart_item_ids:
        cart_items = cart_query.filter(CartItem.id.in_(req.cart_item_ids)).all()
        if len(cart_items) != len(set(req.cart_item_ids)):
            raise errors.param_error("购物车条目无效或不属于当前用户")
    else:
        cart_items = cart_query.all()
    if not cart_items:
        raise errors.biz_error(400, "CART_EMPTY", "购物车为空, 请先加入商品")

    try:
        order, total = create_order_from_products(
            db, user, [(ci.product_id, ci.quantity) for ci in cart_items], "ORDER_CREATE"
        )
        for ci in cart_items:
            db.delete(ci)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    db.refresh(order)
    return order_out(order, total_override=total)


@router.get("", response_model=OrderListOut, summary="我的订单列表")
def list_orders(
    page: int = Query(1, ge=1, description="页码, 从 1 开始"),
    page_size: int = Query(10, ge=1, le=100, description="每页数量, 1-100"),
    status: str = "",
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(Order).filter(Order.user_id == user.id)
    if status:
        query = query.filter(Order.status == status)
    total = query.count()
    offset = (page - 1) * page_size
    orders = query.order_by(Order.id.desc()).offset(offset).limit(page_size).all()
    return {"total": total, "page": page, "page_size": page_size, "items": [order_out(o) for o in orders]}


@router.get("/{order_id}", response_model=OrderOut, summary="订单详情")
def get_order(
    order_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    order = db.query(Order).filter(Order.id == order_id).first()
    if order is None:
        raise errors.not_found("订单不存在")
    return order_out(order)


@router.post("/{order_id}/cancel", response_model=OrderOut, summary="取消订单")
def cancel_order(
    order_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """取消订单: 仅待支付订单可取消; 取消成功回滚已占用库存并写库存流水。

    已取消订单重复取消按幂等处理(返回当前状态, 不重复回滚)。
    """
    order = db.query(Order).filter(Order.id == order_id).first()
    if order is None:
        raise errors.not_found("订单不存在")
    if order.status == OrderStatus.CANCELLED:
        return order_out(order)
    if order.status != OrderStatus.PENDING_PAYMENT:
        raise errors.biz_error(400, "INVALID_STATE", "仅待支付订单可取消")
    # 回滚库存并写流水(澄清会结论 #1: 取消成功时释放已占用库存)
    for item in order.items:
        product = db.get(Product, item.product_id)
        if product is not None:
            product.stock = Product.stock + item.quantity
            db.add(
                InventoryLedger(
                    product_id=item.product_id,
                    change_amount=item.quantity,
                    order_id=order.id,
                    reason="ORDER_CANCEL",
                )
            )
    order.status = OrderStatus.CANCELLED
    order.cancelled_at = datetime.now()
    db.commit()
    db.refresh(order)
    return order_out(order)


@router.post("/{order_id}/ship", response_model=OrderOut, summary="模拟发货(商家操作)")
def ship_order(
    order_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    order = db.query(Order).filter(Order.id == order_id).first()
    if order is None:
        raise errors.not_found("订单不存在")
    if order.status != OrderStatus.PAID:
        raise errors.biz_error(400, "INVALID_STATE", "仅已支付订单可发货")
    order.status = OrderStatus.SHIPPED
    order.shipped_at = datetime.now()
    db.commit()
    db.refresh(order)
    return order_out(order)


@router.post("/{order_id}/complete", response_model=OrderOut, summary="模拟确认收货(完成订单)")
def complete_order(
    order_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    order = db.query(Order).filter(Order.id == order_id).first()
    if order is None:
        raise errors.not_found("订单不存在")
    if order.status != OrderStatus.SHIPPED:
        raise errors.biz_error(400, "INVALID_STATE", "仅已发货订单可确认收货")
    order.status = OrderStatus.COMPLETED
    order.completed_at = datetime.now()
    db.commit()
    db.refresh(order)
    return order_out(order)
