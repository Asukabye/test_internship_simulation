"""统一错误响应结构: {"code": "...", "message": "..."}。"""
from fastapi import HTTPException


def biz_error(status_code: int, code: str, message: str) -> HTTPException:
    return HTTPException(status_code=status_code, detail={"code": code, "message": message})


def param_error(message: str = "请求参数错误") -> HTTPException:
    return biz_error(400, "PARAM_ERROR", message)


def not_found(message: str = "资源不存在") -> HTTPException:
    return biz_error(404, "NOT_FOUND", message)


def unauthorized(message: str = "未登录或登录已过期") -> HTTPException:
    return biz_error(401, "UNAUTHORIZED", message)


def forbidden(message: str = "无权访问该资源") -> HTTPException:
    return biz_error(403, "FORBIDDEN", message)
