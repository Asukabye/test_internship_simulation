"""FastAPI 公共依赖。"""
from fastapi import Depends, Header
from sqlalchemy.orm import Session

import jwt as pyjwt

from . import errors
from .database import get_db
from .models import User
from .security import decode_access_token


def get_current_user(
    authorization: str = Header(default="", description="登录后获取的令牌, 格式: Bearer <token>"),
    db: Session = Depends(get_db),
) -> User:
    """从 Authorization 头解析 JWT 并返回当前登录用户。"""
    if not authorization.startswith("Bearer "):
        raise errors.unauthorized()
    token = authorization[len("Bearer "):].strip()
    try:
        payload = decode_access_token(token)
        user_id = int(payload.get("sub", "0"))
    except (pyjwt.ExpiredSignatureError, pyjwt.InvalidTokenError, ValueError):
        raise errors.unauthorized("登录状态无效或已过期, 请重新登录")
    user = db.get(User, user_id)
    if user is None:
        raise errors.unauthorized()
    return user
