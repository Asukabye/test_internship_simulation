"""E-Shop 在线商城 v1.1 后端入口。"""
from datetime import datetime

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy import text

from .database import SessionLocal
from .routers import addresses, auth, cart, orders, payments, products, reviews, seckill

app = FastAPI(
    title="E-Shop 在线商城 API",
    description=(
        "E-Shop 在线商城 v1.1 后端接口: 用户认证、商品、购物车、订单(含简版秒杀抢购)、"
        "收货地址(v1.1 新增)、订单评价(v1.1 新增)。\n\n"
        "通用约定:\n"
        "- 需要登录的接口请在请求头携带 `Authorization: Bearer <token>`(登录接口返回 access_token);\n"
        "- 错误响应统一为 `{\"code\": \"...\", \"message\": \"...\"}`;\n"
        "- 金额单位: 元; 分页参数: page(从 1 开始), page_size(默认 10, 1-100)。"
    ),
    version="1.1.0",
)

app.include_router(auth.router)
app.include_router(products.router)
app.include_router(cart.router)
app.include_router(orders.router)
app.include_router(payments.router)
app.include_router(seckill.router)
app.include_router(addresses.router)
app.include_router(reviews.router)


@app.get("/health", tags=["系统"], summary="健康检查")
def health_check():
    """健康检查: 返回服务状态与数据库连通状态。"""
    db_status = "ok"
    status = "ok"
    try:
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
    except Exception:
        db_status = "error"
        status = "degraded"
    return {"status": status, "db": db_status, "time": datetime.now().isoformat(timespec="seconds")}


@app.exception_handler(HTTPException)
async def on_http_exception(request: Request, exc: HTTPException):
    """业务错误统一为无包裹结构 {code, message}(与文档约定一致)。

    说明: FastAPI 默认会把 HTTPException.detail 再包一层 {"detail": ...},
    这里覆盖默认 handler, 使业务错误(detail 为 dict)直接作为响应体返回。
    """
    if isinstance(exc.detail, dict):
        return JSONResponse(status_code=exc.status_code, content=exc.detail)
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


@app.exception_handler(RequestValidationError)
async def on_validation_error(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "code": "PARAM_ERROR",
            "message": "请求参数校验失败, 请检查参数格式",
            "details": exc.errors(),
        },
    )


@app.exception_handler(Exception)
async def on_internal_error(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"code": "INTERNAL_ERROR", "message": "服务器内部错误, 请稍后重试"},
    )
