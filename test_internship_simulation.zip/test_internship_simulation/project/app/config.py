"""全局配置: 通过环境变量覆盖, 默认值适合本地一键启动。"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# ---- 数据库连接(默认 root / 123456 @ 127.0.0.1:3306)----
DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = os.getenv("DB_PORT", "3306")
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "123456")
DB_NAME = os.getenv("DB_NAME", "eshop")

# 不带库名的连接串, 用于自动建库
SERVER_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/?charset=utf8mb4"
DATABASE_URL = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"

# ---- JWT ----
JWT_SECRET = os.getenv("JWT_SECRET", "eshop-dev-secret-2024")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_HOURS = 24
