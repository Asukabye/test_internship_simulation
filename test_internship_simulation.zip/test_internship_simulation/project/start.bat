@echo off
chcp 65001 >nul
title E-Shop Online Mall v1.0
cd /d "%~dp0"

echo ============================================
echo    E-Shop Online Mall v1.0 - One-Click Start
echo ============================================
echo.

REM ================= DB CONFIG (edit if needed) =================
REM Default: root / 123456 @ 127.0.0.1:3306, database: eshop
REM If your MySQL root password is NOT 123456, change the line below.
if "%DB_HOST%"=="" set DB_HOST=127.0.0.1
if "%DB_PORT%"=="" set DB_PORT=3306
if "%DB_USER%"=="" set DB_USER=root
if "%DB_PASSWORD%"=="" set DB_PASSWORD=123456
if "%DB_NAME%"=="" set DB_NAME=eshop
REM ==============================================================

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] python not found. Install Python 3.10+ and check "Add Python to PATH".
    pause
    exit /b 1
)

echo [1/4] Installing Python dependencies ...
python -m pip install -r requirements.txt -q
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies. Check your network and retry.
    pause
    exit /b 1
)

echo [2/4] Initializing database (create DB + tables + seed data) ...
python scripts\init_db.py %1
if errorlevel 1 (
    echo [ERROR] Database init failed.
    echo         Check: 1. Is MySQL service running?  2. Is the DB account/password above correct?
    pause
    exit /b 1
)

echo [3/4] Generating API doc (openapi.json) ...
python scripts\export_openapi.py >nul 2>nul

echo [4/4] Starting server (press Ctrl+C to stop) ...
echo.
echo   Service URL:  http://127.0.0.1:8000
echo   Health check: http://127.0.0.1:8000/health
echo   API docs:     http://127.0.0.1:8000/docs
echo.
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

pause
