#!/usr/bin/env bash
# E-Shop 在线商城 v1.0 一键启动 (macOS / Linux)
# 用法: ./start.sh           首次启动(自动建库 + 建表 + 造数)
#       ./start.sh --reset   重置数据库后启动
set -e
cd "$(dirname "$0")"

export DB_HOST="${DB_HOST:-127.0.0.1}"
export DB_PORT="${DB_PORT:-3306}"
export DB_USER="${DB_USER:-root}"
export DB_PASSWORD="${DB_PASSWORD:-123456}"
export DB_NAME="${DB_NAME:-eshop}"

echo "============================================"
echo "   E-Shop 在线商城 v1.0 一键启动"
echo "============================================"

if ! command -v python3 >/dev/null 2>&1; then
    echo "[错误] 未找到 python3, 请先安装 Python 3.10+"
    exit 1
fi

echo "[1/4] 安装 Python 依赖 ..."
python3 -m pip install -r requirements.txt -q

echo "[2/4] 初始化数据库(自动建库 + 建表 + 造数) ..."
python3 scripts/init_db.py "$@"

echo "[3/4] 生成接口文档(openapi.json) ..."
python3 scripts/export_openapi.py >/dev/null 2>&1 || true

echo "[4/4] 启动服务(按 Ctrl+C 停止) ..."
echo
echo "  服务地址:   http://127.0.0.1:8000"
echo "  健康检查:   http://127.0.0.1:8000/health"
echo "  接口文档:   http://127.0.0.1:8000/docs"
echo
exec python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000
